CREATE DATABASE Legivallalatok;
USE Legivallalatok;

CREATE TABLE Legitarsasag (
  nev VARCHAR(30) NOT NULL PRIMARY KEY,
  orszag VARCHAR(30) NOT NULL,
  alapitas_eve INT NOT NULL,
  flotta_meret INT NOT NULL,
  celallomas INT NOT NULL);
  
INSERT INTO Legitarsasag VALUES ('Aegean Airlines','Görögország',1987,61,161);
INSERT INTO Legitarsasag VALUES ('Qantas','Ausztrália',1920,142,144);
INSERT INTO Legitarsasag VALUES ('Wizz Air','Magyarország',2003,179,194);
INSERT INTO Legitarsasag VALUES ('Turkish Airlines','Törökország',1933,318,283);
INSERT INTO Legitarsasag VALUES ('British Airways','Egyesült Királyság',1974,265,169);
INSERT INTO Legitarsasag VALUES ('Eurowings','Németország',1990,90,137);
INSERT INTO Legitarsasag VALUES ('KLM','Hollandia',1919,118,136);