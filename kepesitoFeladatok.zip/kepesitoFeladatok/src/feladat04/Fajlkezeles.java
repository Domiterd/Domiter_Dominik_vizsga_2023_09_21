package feladat04;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Fajlkezeles {

	public List<Varos> fajlOlvas(String varos) throws IOException {

		List<Varos> varosok = new ArrayList<Varos>();

		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(varos), "UTF-8"));
		
		String header = br.readLine();
		
		while (br.ready()) {
			
			String csvSor[] = br.readLine().split(";");
			
				varosok.add(new	Varos(csvSor));
				
			
		}
		br.close();
		// TODO 

		return varosok;
	}

}
