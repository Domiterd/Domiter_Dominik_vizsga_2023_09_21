package feladat04;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class NagyvarosokApp {

	public static void main(String[] args) throws IOException {
		
		Scanner sc = new Scanner(System.in);
		
		Fajlkezeles fajlObj = new Fajlkezeles();
				
		List<Varos> varosok = fajlObj.fajlOlvas("varosok.csv");
		
		for (Varos varos : varosok) {
			System.out.println(varos.toString());
		}
		
		System.out.println();
		System.out.println("Adjon meg egy városkódot!");
		String orszagkod = sc.nextLine();
		
		
		int tmp = 0;
		for (Varos varos : varosok) {
			if (varos.getOrszagkod().equalsIgnoreCase(orszagkod)) {
				System.out.println(varos.toString());
				tmp++;
			}
		}
		if (tmp == 0) {
			System.out.println("Nem található ilyen városkód!");
		}
		// TODO

	}


}
