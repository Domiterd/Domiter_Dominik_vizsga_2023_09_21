package feladat04;

public class Varos {
	
	private String nev;
	private String orszagkod;
	private int nepesseg;
	private double terulet;
	
	public Varos(String[] csvSor) {
		
		nev = csvSor[0];
		orszagkod = csvSor[1];
		nepesseg = Integer.parseInt(csvSor[2]);
		terulet = Double.parseDouble(csvSor[3]);
	}

	public String getNev() {
		return nev;
	}

	public String getOrszagkod() {
		return orszagkod;
	}

	public int getNepesseg() {
		return nepesseg;
	}

	public double getTerulet() {
		return terulet;
	}

	@Override
	public String toString() {
		return "Varos [nev=" + nev + ", orszagkod=" + orszagkod + ", nepesseg=" + nepesseg + ", terulet=" + terulet
				+ "]";
	}
	
	
	
	

	// TODO
	
}
