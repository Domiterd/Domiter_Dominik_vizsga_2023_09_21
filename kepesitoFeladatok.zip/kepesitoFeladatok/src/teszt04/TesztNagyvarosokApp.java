package teszt04;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import feladat04.Fajlkezeles;
import feladat04.Varos;

class TesztNagyvarosokApp {

	@Test
	void tesztFajlOlvas() throws IOException {
		
		Fajlkezeles fajlObj = new Fajlkezeles();
		assertTrue(fajlObj.fajlOlvas("varosok.csv").size()>0);
		
	}
	@Test
	void tesztToString() {
		String[] string = {"Bécs","AUT","1973403","414.9"};
		Varos varos = new Varos(string); 
		assertEquals("Varos [nev=Bécs, orszagkod=AUT, nepesseg=1973403, terulet=414.9]", varos.toString());
	}
	

}
