package feladat03;

import java.util.ArrayList;
import java.util.List;

public class FociligaApp {

	public static void main(String[] args) {
		
		Adatbekérés adatbekeres = new Adatbekérés();
		
		List<Csapat> csapatok = new ArrayList<>();
		
		adatbekeres.adatbekeres(csapatok);
		
		kiiratas(csapatok);
		
		
	}
	public static void kiiratas(List<Csapat> csapatok) {
		for (Csapat csapat : csapatok) {
			System.out.println(csapat.toString() + " átlag: " + csapat.atlag());
		}
		
		double legkevesebb = csapatok.get(0).atlag();
		double legtobb = csapatok.get(0).atlag();
		
		for (Csapat csapat : csapatok) {
			if (csapat.atlag() > legtobb) {
				legtobb = csapat.atlag();
			}
			if (csapat.atlag() < legkevesebb) {
				legkevesebb = csapat.atlag();
			}
		}
		for (Csapat csapat : csapatok) {
			if (csapat.atlag() == legkevesebb) {
				System.out.println("A legkevebb átlagú csapat: " + csapat.getNev());
			}
			if (csapat.atlag() == legtobb) {
				System.out.println("A legnayobb átlagú csapat: " + csapat.getNev());
			}
		}
		
		
	}
	


}
