package feladat03;

import java.util.List;
import java.util.Scanner;

public class Adatbekérés {
	
	Scanner sc = new Scanner(System.in);
	
	public void adatbekeres(List<Csapat> csapatok) {
		System.out.println("Adja meg 5 csapat nevét, gyözelmeit, döntelenek, vereségeit (vesszővel elválasztva)");
		int i = 0;
		while (i != 5) {
			String adat = sc.nextLine();
			String[] adatok = adat.split(",");
			csapatok.add(new Csapat(adatok[0],Integer.parseInt(adatok[1]),
					Integer.parseInt(adatok[2]),Integer.parseInt(adatok[3])));
			i++;
		}
		
		
	}
}

