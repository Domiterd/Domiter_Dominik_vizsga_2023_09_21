package feladat03;

public class Csapat {
	
	private String nev;
	private int gyozelem;
	private int dontetlen;
	private int vereseg;
	
	
	public Csapat(String nev, int gyozelem, int dontetlen, int vereseg) {

		this.nev = nev;
		this.gyozelem = gyozelem;
		this.dontetlen = dontetlen;
		this.vereseg = vereseg;
		
	}
	
	
	public String getNev() {
		return nev;
	}


	public int getGyozelem() {
		return gyozelem;
	}


	public int getDontetlen() {
		return dontetlen;
	}


	public int getVereseg() {
		return vereseg;
	}


	@Override
	public String toString() {
		return "Csapat [nev=" + nev + ", gyozelem=" + gyozelem + ", dontetlen=" + dontetlen + ", vereseg=" + vereseg
				+ "]";
	}


	public double atlag() {
		
		int merkozesekSzama = gyozelem + dontetlen + vereseg;
		int osszpontszam = (gyozelem * 3) + (dontetlen);
		
		return (double)osszpontszam / merkozesekSzama;
		
	}


}
