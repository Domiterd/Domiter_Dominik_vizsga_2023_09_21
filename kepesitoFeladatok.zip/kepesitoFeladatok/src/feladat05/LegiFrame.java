package feladat05;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LegiFrame {

	private JFrame frame;
	
	private ABKezelo dbMotor;
	private DefaultTableModel model;
	
	private List<Repulotarsasag> tarsasagok;
	private JTable table;
	private JButton btnTorles;

	public JFrame getFrame() {
		return frame;
	}


	public LegiFrame() {
		
		initialize();
		try {
			
			dbMotor = new ABKezelo("jdbc:mysql://localhost:3306/Legivallalatok?autoReconnect=true&useSSL=false","root","Ruander2000");
			
			tarsasagok = dbMotor.adatBeolvas();
			
			listaTablabaTolt();
			
		} catch (SQLException e) {
			
			JOptionPane.showMessageDialog(frame, e.getMessage(), "DB Hiba",	JOptionPane.ERROR_MESSAGE);
			System.exit(0);
			
		}
	}


	private void initialize() {
		
		frame = new JFrame();

		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				
				
				System.exit(0);
				
			}
		});
		frame.setTitle("Légitársaságok");
		frame.setBounds(100, 100, 550, 450);		
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		
		frame.getContentPane().setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(38, 33, 461, 240);
		frame.getContentPane().add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		String oszlopNevek[] = {"Légitársaság","Ország","Alapítás éve","Flotta (db)","Célállomás (db)"};
		model = new DefaultTableModel(null,oszlopNevek);
		table.setModel(model);
		
		btnTorles = new JButton("Törlés");
		btnTorles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				int rowIndex = table.getSelectedRow();
				if (rowIndex == -1) {
					JOptionPane.showMessageDialog(frame, "Nincs sor kijelölve");;
				}
				else {
					int a = JOptionPane.showConfirmDialog(frame, "Biztosan törölni szeretné a tételt?");
					if (a == JOptionPane.YES_OPTION) {
						delete(rowIndex);
						
					}
				}
				
			}
		});
		btnTorles.setBounds(38, 284, 107, 30);
		frame.getContentPane().add(btnTorles);
		

		DefaultTableCellRenderer crenderer = new DefaultTableCellRenderer();
		crenderer.setHorizontalAlignment(SwingConstants.CENTER);
		for ( int i=0; i < model.getColumnCount(); i++ ) {
			table.getColumnModel().getColumn(i).setCellRenderer(crenderer);
		}
		
	}
	
	
	public void delete(int rowIndex) {
				
	}


	private void listaTablabaTolt() {
		
		for (Repulotarsasag tarsasag : tarsasagok) {
			
			Object[] adatok = new Object[] 
					{tarsasag.getNev(), tarsasag.getOrszag(), tarsasag.getAlapitas(), 
					 tarsasag.getFlottameret(), tarsasag.getCelallomasokSzama()}; 
			
			model.insertRow(table.getRowCount(), adatok);
		}		
	}
}
