package feladat05;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ABKezelo {
	
private static Connection con;
	
	public ABKezelo(String connectionURL, String user, String pw) throws SQLException {
		
		csatlakozas(connectionURL, user, pw);
		
	}

	public void csatlakozas(String connectionURL, String user, String pw) throws SQLException {

		try {		

			con = (Connection) DriverManager.getConnection(connectionURL, user, pw);

		} catch (Exception e) {

			throw new SQLException("A csatlakozás sikertelen! " + e.getMessage());
		}
	}

	public void kapcsolatBontas() throws SQLException {

		try {

			con.close();

		} catch (Exception e) {

			throw new SQLException("A kapcsolat bontása sikertelen! " + e.getMessage());
		}

	}
	
	
	public List<Repulotarsasag> adatBeolvas() throws SQLException{
		
		try {
			
			List<Repulotarsasag> tarsasagok = new ArrayList<Repulotarsasag>();
			
			PreparedStatement ps = con.prepareStatement("SELECT * FROM Legitarsasag");
			
			ResultSet res = ps.executeQuery();
			
	        while (res.next()) {
	        	tarsasagok.add(new Repulotarsasag(
	        			res.getString("nev"),
	        			res.getString("orszag"),
	        			res.getInt("alapitas_eve"),
	        			res.getInt("flotta_meret"),
	        			res.getInt("celallomas")
	        			));
	        }
	        
			res.close(); 
			return tarsasagok;
			
		} catch (Exception e) {
			
			throw new SQLException("Adatbázisból olvasás sikertelen!");
			
		}
				
	}

}
