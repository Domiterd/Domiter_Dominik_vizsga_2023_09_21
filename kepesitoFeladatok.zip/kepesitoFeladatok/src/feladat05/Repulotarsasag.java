package feladat05;

public class Repulotarsasag {
	
	private String nev;
	private String orszag;
	private int alapitas;
	private int flottameret;
	private int celallomasokSzama;


	public Repulotarsasag(String nev, String orszag, int alapitas, int flottameret, int celallomasokSzama) {

		this.nev = nev;
		this.orszag = orszag;
		this.alapitas = alapitas;
		this.flottameret = flottameret;
		this.celallomasokSzama = celallomasokSzama;
		
	}
	
	
	public String getNev() {
		return nev;
	}


	public String getOrszag() {
		return orszag;
	}


	public int getAlapitas() {
		return alapitas;
	}


	public int getFlottameret() {
		return flottameret;
	}


	public int getCelallomasokSzama() {
		return celallomasokSzama;
	}

}
