package feladat05;

public class LegitarsasagApp {

	public static void main(String[] args) {
		
		LegiFrame foAblak = new LegiFrame();
		foAblak.getFrame().setVisible(true);
				
	}
}
