package teszt01;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat01.JegygeneraloApp;


class TesztJegygeneraloApp {

	
	@Test
	void tesztGeneral() {
		
		assertEquals(300, JegygeneraloApp.general("A padlás", 15,20).length);
		
	}
}
