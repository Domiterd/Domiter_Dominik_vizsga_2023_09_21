package teszt02;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat02.Jatek;

class TesztJatek {

	@Test
	void tesztArkepzo() {
		
		Jatek jatekObj = new Jatek("Barbie baba", "C0001", 5700, 22);
		assertTrue(jatekObj.arkepzo());
		
	}
	@Test
	void tesztToString() {
		
		Jatek jatekObj = new Jatek("Kis autó","0001",2000,12);
		assertEquals("Jatek [megnevezes=Kis autó, cikkszam=0001, ar=2000, darab=12]", jatekObj.toString());
	}
	
	

}
