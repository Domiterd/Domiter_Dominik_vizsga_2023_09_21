package teszt05;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

import feladat05.ABKezelo;


class TesztLegitarsasag {

	@Test
	void tesztABKezeloAdatBeolvas() throws SQLException {
		
		ABKezelo dbMotor = new ABKezelo("jdbc:mysql://localhost:3306/Legivallalatok?autoReconnect=true&useSSL=false","root","Ruander2000");
		
		assertTrue(dbMotor.adatBeolvas().size()>0);
				
	}

}
