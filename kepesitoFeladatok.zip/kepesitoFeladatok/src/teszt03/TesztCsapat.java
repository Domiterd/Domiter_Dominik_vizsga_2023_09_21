package teszt03;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import feladat03.Csapat;

class TesztCsapat {

	@Test
	void tesztAtlag() {
		
		Csapat csapatObj = new Csapat("FC Barcelona", 29, 8, 1);
		double elvartAtlag = 2.5;
		
		assertEquals(elvartAtlag,csapatObj.atlag());
	}
	@Test
	void teszToString() {
		Csapat csapatObj = new Csapat("FC Barcelona", 29, 8, 1);
		String elvartString = "Csapat [nev=FC Barcelona, gyozelem=29, dontetlen=8, vereseg=1]";
		assertEquals(elvartString, csapatObj.toString());
	}

	
}
