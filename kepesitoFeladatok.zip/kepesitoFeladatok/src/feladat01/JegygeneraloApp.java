package feladat01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class JegygeneraloApp {
	
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
			
			String cim ="";
			int sorokSzama = 0;
			int szekekSzama = 0;
			
			System.out.println("Adja meg a cimet");
			cim = sc.nextLine();
			System.out.println("Adja meg a sorok számát");
			sorokSzama=Integer.parseInt(sc.nextLine());
			System.out.println("Adja meg a székek számát");
			szekekSzama=Integer.parseInt(sc.nextLine());
			
			kiiratas(general(cim,sorokSzama,szekekSzama));

	}
	
	public static void kiiratas(String[] adatok) {
		List<String> adattagok = new ArrayList<>();
		for (int i = 0; i < adatok.length; i++) {
			adattagok.add(adatok[i]);
		}
		Collections.reverse(adattagok);
		for (String string : adattagok) {
			System.out.println(string);
		}
		
		
	}
	
	
	public static String[] general(String cim, int sorokSzama, int szekekSzama) {
		
		String[] adatok = new String[sorokSzama*szekekSzama];
		
		int sorok = 1;
		int szekek = 1;
		int i = 0;
				while (sorok != sorokSzama+1) {
					while (szekek!=szekekSzama+1) {
					adatok[i] = cim + " " + sorok + ". sor " + szekek + ". szék";
					szekek++;
					i++;
					}
					szekek = 1;
					sorok++;
				}
			
		
		
		return adatok;
		
	}

}
