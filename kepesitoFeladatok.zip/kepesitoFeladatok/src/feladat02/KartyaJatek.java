package feladat02;

public class KartyaJatek extends Jatek {
	
	private int kartyalapokszama;

	public KartyaJatek(String megnevezes, String cikkszam, int ar, int darab, int kartyalapokszama) {
		super(megnevezes, cikkszam, ar, darab);
		this.kartyalapokszama = kartyalapokszama;
	}

	public int getKartyalapokszama() {
		return kartyalapokszama;
	}

	@Override
	public String toString() {
		return "KartyaJatek [kartyalapokszama=" + kartyalapokszama + ", Megnevezes=" + getMegnevezes()
				+ ", Cikkszam=" + getCikkszam() + ", Ar=" + getAr() + ", Darabz=" + getDarab() + "]";
	}

}
