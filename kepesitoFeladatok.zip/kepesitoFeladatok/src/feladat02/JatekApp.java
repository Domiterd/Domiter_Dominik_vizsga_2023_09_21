package feladat02;

import java.util.ArrayList;
import java.util.List;

public class JatekApp {

	public static void main(String[] args) {
		
		List<Jatek> jatekok = new ArrayList<>();
		
		Jatek jatek1 = new Jatek("Kis autó", "0001", 2000, 12);
		Jatek jatek2 = new KartyaJatek("Magyar kártya", "0002", 3000, 2, 50);
		Jatek jatek3 = new TarsasJatek("Monopoly", "0003", 10000, 4, 6);
		
		jatekok.add(jatek1);
		jatekok.add(jatek2);
		jatekok.add(jatek3);
		
		
			
		for (Jatek jatek : jatekok) {
			String a = "";
			if (jatek.arkepzo()) {
				a = "árváltoras történt";
			}	
			else {
				a = "nem történt árváltozás";
			}
				
			System.out.println(jatek.toString() + " " + a);
		}
		

	}

}
