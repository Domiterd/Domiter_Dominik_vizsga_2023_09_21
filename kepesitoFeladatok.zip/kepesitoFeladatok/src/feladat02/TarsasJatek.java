package feladat02;

public class TarsasJatek extends Jatek{
	
	private int maxjatekos;

	public TarsasJatek(String megnevezes, String cikkszam, int ar, int darab, int maxjatekos) {
		super(megnevezes, cikkszam, ar, darab);
		this.maxjatekos = maxjatekos;
	}

	public int getMaxjatekos() {
		return maxjatekos;
	}

	@Override
	public String toString() {
		return "TarsasJatek [maxjatekos=" + maxjatekos + ", Megnevezes=" + getMegnevezes()
		+ ", Cikkszam=" + getCikkszam() + ", Ar=" + getAr() + ", Darabz=" + getDarab() + "]";
	}
}
