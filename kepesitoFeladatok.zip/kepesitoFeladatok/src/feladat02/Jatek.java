package feladat02;

public class Jatek {
	
	private String megnevezes;
	private String cikkszam;
	private int ar;
	private int darab;
	
	
	public Jatek(String megnevezes, String cikkszam, int ar, int darab) {

		this.megnevezes = megnevezes;
		this.cikkszam = cikkszam;
		this.ar = ar;
		this.darab = darab;
	}
	
	
	public String getMegnevezes() {
		return megnevezes;
	}


	public String getCikkszam() {
		return cikkszam;
	}


	public int getAr() {
		return ar;
	}


	public int getDarab() {
		return darab;
	}


	@Override
	public String toString() {
		return "Jatek [megnevezes=" + megnevezes + ", cikkszam=" + cikkszam + ", ar=" + ar + ", darab=" + darab + "]";
	}


	public boolean arkepzo() {
		
		if (darab > 20) {
			
			ar = (int)(ar * 0.9);
			return true;
			
		}
		else if (darab >= 1 && darab <= 10) {
			
			ar += (int)(ar * 1.2);
			return true;
			
		}
		return false;
		
	}


}
